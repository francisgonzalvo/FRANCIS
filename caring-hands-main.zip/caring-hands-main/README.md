# Caring Hands
Caring Hands is ...ilagay mo dito yung gusto mong description...

It has the following features:
* See Donation Drives
* Start Donation Drive
* Cancel Donation Drive
* Check Donation Drive
* See Donors
* See Beneficiaries
* Add Donor
* Add Beneficiary
* Remove Donor
* Remove Beneficiary
* Disburse Donation
* See Past Disbursement
